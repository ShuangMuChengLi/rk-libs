v1.0.1 - Tue, 09 Sep 2014 15:13:20 GMT
--------------------------------------

- [6af7364](../../commit/6af7364) [fixed] use self instead of this for worker to work with workerify
- [b1fe90c](../../commit/b1fe90c) [fixed] hard-code path to worker so it gets picked up by workerify
- [1337c9d](../../commit/1337c9d) [fixed] make browserify and workerify peer deps


v1.0.0 - Sun, 07 Sep 2014 14:25:06 GMT
--------------------------------------

- [927af5d](../../commit/927af5d) [added] npm and browserify support
- [0580cdc](../../commit/0580cdc) [fixed] use correct RIFF chunk size


