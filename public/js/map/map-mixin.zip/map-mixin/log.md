# 2022-04-01
1. showPolygon方法设置随机默认颜色
